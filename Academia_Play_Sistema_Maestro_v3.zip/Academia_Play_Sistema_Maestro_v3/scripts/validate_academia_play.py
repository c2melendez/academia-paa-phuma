#!/usr/bin/env python3
"""Static contract checks for illustrative Academia Play manifests, not pedagogy certification."""
import json
import sys
from pathlib import Path


def validate(data):
    errors = []
    if data.get("platform") != "Academia Play":
        errors.append("platform must be Academia Play")
    courses = data.get("courses", [])
    if not courses:
        errors.append("at least one imported course is required")
    objectives = set()
    module_ids = set()
    course_ids = set()
    for course in courses:
        cid = course.get("id")
        if not cid or cid in course_ids:
            errors.append(f"invalid or repeated course ID: {cid}")
        course_ids.add(cid)
        obj = {f"{cid}:{o}" for o in course.get("objectives", [])}
        objectives.update(obj)
        module_list = course.get("modules", [])
        local = set()
        covered = set()
        for module in module_list:
            mid = module.get("id")
            if not mid or mid in local:
                errors.append(f"invalid/repeated module: {cid}/{mid}")
            local.add(mid)
            module_ids.add((cid, mid))
            covered.update(module.get("objective_ids", []))
        for module in module_list:
            for dep in module.get("depends_on", []):
                if dep not in local:
                    errors.append(f"missing module dependency {cid}/{dep}")
        if not set(course.get("objectives", [])) <= covered:
            errors.append(f"uncaptured objectives for {cid}: {sorted(set(course.get('objectives', [])) - covered)}")
        errors.extend(_cycles({m.get("id"): m.get("depends_on", []) for m in module_list}, f"module:{cid}"))
    lab_ids = set()
    for lab in data.get("laboratories", []):
        lab_id = lab.get("lab_id")
        if not lab_id or lab_id in lab_ids:
            errors.append(f"invalid/repeated lab id: {lab_id}")
        lab_ids.add(lab_id)
        for field in ("engine_id", "capabilities", "course_objective_refs", "scenario_ids", "oracle_ids", "accessibility_fallbacks", "coverage_test_ids", "revision"):
            if not lab.get(field):
                errors.append(f"lab {lab_id} missing {field}")
        if lab.get("reuse_decision") not in {"REUSE", "EXTEND", "CREATE"}:
            errors.append(f"lab {lab_id} invalid reuse_decision")
        for objref in lab.get("course_objective_refs", []):
            if objref not in objectives:
                errors.append(f"lab {lab_id} references unavailable course objective: {objref}")
    for lab in data.get("laboratories", []):
        for dependency in lab.get("dependencies", []):
            if dependency not in lab_ids:
                errors.append(f"unknown lab dependency: {dependency}")
    for path in data.get("learning_paths", []):
        cid = path.get("course_id")
        if cid not in course_ids:
            errors.append(f"unknown learning path course: {cid}")
        nodes = path.get("nodes", [])
        ids = [n.get("id") for n in nodes]
        if len(ids) != len(set(ids)):
            errors.append(f"duplicate node in learning path {cid}")
        for n in nodes:
            if (cid, n.get("module_id")) not in module_ids:
                errors.append(f"unknown module in learning path: {cid}/{n.get('module_id')}")
            if n.get("repeat_access") is not True:
                errors.append(f"node must retain access after unlocking: {n.get('id')}")
            if n.get("unlock_policy") != "MASTERY":
                errors.append(f"node must unlock by demonstrated mastery: {n.get('id')}")
        graph = {n.get("id"): n.get("depends_on", []) for n in nodes}
        for n in nodes:
            for dep in n.get("depends_on", []):
                if dep not in graph:
                    errors.append(f"missing path prerequisite {cid}/{dep}")
        errors.extend(_cycles(graph, f"path:{cid}"))
    return errors


def _cycles(graph, prefix):
    errors = []
    visited, visiting = set(), set()
    def visit(node):
        if node in visiting:
            errors.append(f"dependency cycle: {prefix}/{node}")
            return
        if node in visited:
            return
        visiting.add(node)
        for dep in graph.get(node, []):
            if dep in graph:
                visit(dep)
        visiting.remove(node)
        visited.add(node)
    for node in graph:
        visit(node)
    return errors


def main():
    if len(sys.argv) != 2:
        print("Usage: python validate_academia_play.py path/to/manifest.json")
        return 2
    payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    problems = validate(payload)
    if problems:
        print("FAIL:\n" + "\n".join(f"- {e}" for e in problems))
        return 1
    print("PASS: structural manifest checks (not scientific or academic certification)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
