import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from validate_academia_play import validate


class ManifestTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sample = json.loads((ROOT / "schemas/academia_play_ejemplo.json").read_text())

    def test_example(self):
        self.assertEqual(validate(copy.deepcopy(self.sample)), [])

    def test_orphan_laboratory(self):
        data = copy.deepcopy(self.sample)
        data["laboratories"][0]["course_objective_refs"] = ["chem1:atomic"]
        self.assertTrue(any("unavailable" in e for e in validate(data)))

    def test_missing_oracle(self):
        data = copy.deepcopy(self.sample)
        data["laboratories"][0]["oracle_ids"] = []
        self.assertTrue(any("oracle_ids" in e for e in validate(data)))

    def test_unlock_remains_accessible(self):
        data = copy.deepcopy(self.sample)
        data["learning_paths"][0]["nodes"][0]["repeat_access"] = False
        self.assertTrue(any("retain access" in e for e in validate(data)))

    def test_detect_cycle(self):
        data = copy.deepcopy(self.sample)
        modules = data["courses"][0]["modules"]
        modules.append({"id": "second", "objective_ids": [], "depends_on": ["unit-functions"]})
        modules[0]["depends_on"] = ["second"]
        self.assertTrue(any("cycle" in e for e in validate(data)))

    def test_duplicate_lab(self):
        data = copy.deepcopy(self.sample)
        data["laboratories"].append(copy.deepcopy(data["laboratories"][0]))
        self.assertTrue(any("repeated lab" in e for e in validate(data)))


if __name__ == "__main__":
    unittest.main()
