# Academia Play — sistema maestro v3.0

Iniciar leyendo `PROMPT_MAESTRO.md`. Esta entrega es **un sistema de especificación y validación preliminar**, no una aplicación desplegada ni una certificación académica. `docs/BASE_v2_REFERENCIA.md` conserva la propuesta previa, que queda subordinada a v3. Los manifiestos en `schemas/` son *ejemplos sintéticos*, no sílabos reales.

Para validar el ejemplo: `python scripts/validate_academia_play.py schemas/academia_play_ejemplo.json`. Para comprobar que el validador detecta errores: `python -m unittest discover -s tests -v`.

En `INICIAR`, el agente debe verificar permisos y existencia del repositorio `academia-play`, solicitar autorización para crearlo si falta, establecer infraestructura y solo entonces continuar el curso adjunto. En `AGREGAR_CURSO`, nunca vuelve a crear la infraestructura.
