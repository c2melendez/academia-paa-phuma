# Evaluación de diseños y estudios de eficacia

La evidencia da soporte general a aprendizaje activo, recuperación y práctica espaciada; no demuestra que un juego específico sea el mejor para todo objetivo. Para cada familia de objetivos:

1. Definir criterio observable de dominio y retención con pre/post y variante transferida.
2. Presentar tres alternativas, una sin animación/simulación. Anotar beneficios y riesgos de carga cognitiva, accesibilidad y coste.
3. Usar rúbrica 0–4 para alineación curricular, manipulación conceptualmente relevante, feedback causal, transferibilidad, accesibilidad y testabilidad. Justificar puntuaciones y límites, sin tratarlas como efectos empíricos.
4. Diseñar piloto comparativo ético, con retención diferida, no solo tiempo de uso ni tasa de aciertos repetidos.
5. Registrar `NO_EVIDENCE` donde falte investigación específica y `MANUAL_REVIEW` para corrección conceptual abierta.

Referencias iniciales verificadas:
- Freeman et al., 2014, *Active learning increases student performance in science, engineering, and mathematics*. DOI: 10.1073/pnas.1319030111. https://pubmed.ncbi.nlm.nih.gov/24821756/
- Dunlosky et al., 2013, *Improving Students' Learning With Effective Learning Techniques*. https://pubmed.ncbi.nlm.nih.gov/26173288/
- Soderstrom & Bjork, 2015, *Learning Versus Performance: An Integrative Review*. https://pubmed.ncbi.nlm.nih.gov/25910388/
