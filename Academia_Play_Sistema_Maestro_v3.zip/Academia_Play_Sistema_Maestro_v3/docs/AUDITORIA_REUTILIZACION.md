# Auditoría preliminar de patrones de Precision Lab (lectura directa de repositorios, 20-XI-2026)

Estas observaciones identifican candidatos, NO certifican su reutilización.

| Fuente | Ruta real inspeccionada | Hallazgo | Decisión preliminar |
|---|---|---|---|
| Precision Lab Plus | `frontend/src/components/MathRenderer.tsx` | KaTeX `renderToString`, fallback a texto si LaTeX inválido; salida convertida a HTML por la propia biblioteca | ADAPT: `MathDisplay`, validar seguridad/a11y/MathML |
| Precision Lab Lite | `src/components/NaturalInput.tsx` | Wrapper MathLive `<math-field>`; input con cambio LaTeX y control de teclado | ADAPT: entrada natural separada del cálculo |
| Precision Lab Lite | `src/components/GraphViewer.tsx` | SVG, varias curvas, puntos críticos, huecos removibles | ADAPT: primitivas 2D ligeras |
| Precision Lab Plus | `frontend/src/components/GraphViewer.tsx` | Importación diferida Plotly, trazas 2D/3D, huecos y exportación | ADAPT: visualización avanzada bajo demanda |
| Precision Lab Plus | `backend/app/services/step_verification.py` | Oráculos escalares, matrices, ecuaciones; fallback numérico | ADAPT: añadir manejo formal de dominio, aislamiento de cálculo y oráculos disciplinarios |
| Axis Suite ZIP | `scripts/qa_suite/` | Auditorías de cobertura, dependencias, seguridad, concurrencia, mutaciones, secretos | ADAPT: estructura orquestada, no lógica ERP |

Referencias:
- https://github.com/c2melendez/precision-lab-plus/blob/main/frontend/src/components/MathRenderer.tsx
- https://github.com/c2melendez/precision-lab-lite/blob/main/src/components/NaturalInput.tsx
- https://github.com/c2melendez/precision-lab-lite/blob/main/src/components/GraphViewer.tsx
- https://github.com/c2melendez/precision-lab-plus/blob/main/frontend/src/components/GraphViewer.tsx
- https://github.com/c2melendez/precision-lab-plus/blob/main/backend/app/services/step_verification.py

## Hallazgos de seguridad o diseño que requieren inspección adicional

El timeout de Plus usa `ThreadPoolExecutor` para computación SymPy, y el código advierte que no cancela la tarea; no heredar esa técnica como aislamiento de procesos. La validez de las gráficas exige dominios y discontinuidades del input original. KaTeX no evalúa expresiones; MathLive no certifica equivalencias. La validación de licencias, commits canónicos, comportamiento E2E, accesibilidad y compatibilidad debe realizarse antes de portar. Los READMEs contienen secciones históricas: no asumir que cada declaración antigua describe HEAD actual.
